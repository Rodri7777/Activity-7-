<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DivisionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $data = [
            [
            'Conference' => 'American',
            'Division' => 'North',
            ],
            [
            'Conference' => 'American',
            'Division' => ' South',
            ],
            [
            'Conference' => 'American',
            'Division' => ' East',
            ],
            [
            'Conference' => 'American',
            'Division' => ' West',
            ],
                [
                'Conference' => 'National',
                'Division' => ' North',
                ],
                [
                'Conference' => 'National',
                'Division' => ' South',
                ],
                [
                'Conference' => 'National',
                'Division' => ' East',
                ],
                [
                'Conference' => 'National',
                'Division' => 'West',
                ]
        ];
        DB::table('divisions')->insert($data);
    }
}
